package com.example.sesh.songlibrary;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

public class SongLib extends AppCompatActivity {

    public static final int ADD_SONG_CODE=1;
    public static final int EDIT_SONG_CODE=2;

    private MySongList myList;
    private ListView listView;
    private int lastPickedIndex;
    private int searchListStartPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);

        // get instance of MySongList
        //myList = MySongList.getInstance();

        /*
        // load initial set of songs
        String[] initSongs = getResources().getStringArray(R.array.song_array);

        // break songs into name and artist, add to list
        for (String song : initSongs) {
            int pos = song.indexOf('|');
            myList.add(song.substring(0, pos), song.substring(pos + 1),
                    null, null);
        }
        */

        Toolbar toolbar = (Toolbar)findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);


        try {
            myList = MySongList.getInstance(this);
            //myList.setContext(this);
            //myList.load();
        } catch (IOException e) {
            Toast.makeText(this, "Error loading songs", Toast.LENGTH_LONG)
                    .show();
        }

        // get ListView object
        listView = (ListView) findViewById(R.id.song_list);

        // fit listView with adapter off of myList, and song layout
        /*
        listView.setAdapter(
                new ArrayAdapter<Song>(this, R.layout.song, myList.getSongs()));


        // listen to item click
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        showSong(i);
                    }
                }
        );
        */

        handleIntent(getIntent());

        // for contextual action mode
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        listView.setMultiChoiceModeListener(
                new AbsListView.MultiChoiceModeListener() {
                    @Override
                    public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
                        // Respond to clicks on the actions in the CAB
                        switch (menuItem.getItemId()) {
                            case R.id.action_delete:
                                deleteSelectedItems();
                                actionMode.finish(); // Action picked, so close the CAB
                                return true;
                            default:
                                return false;
                        }

                    }

                    @Override
                    public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                        // Inflate the menu for the CAB
                        MenuInflater inflater = mode.getMenuInflater();
                        inflater.inflate(R.menu.delete_menu, menu);
                        return true;
                    }

                    @Override
                    public void onItemCheckedStateChanged(ActionMode mode, int position,
                                                          long id, boolean checked) {
                        // Here you can do something when items are selected/de-selected,
                        // such as update the title in the CAB
                        mode.setTitle(listView.getCheckedItemCount() +
                                        " selected");
                    }

                    @Override
                    public void onDestroyActionMode(ActionMode mode) {
                        // Here you can make any necessary updates to the activity when
                        // the CAB is removed. By default, selected items are deselected/unchecked.
                    }

                    @Override
                    public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                        // Here you can perform updates to the CAB due to
                        // an invalidate() request
                        return false;
                    }

        });
    }


    private void deleteSelectedItems() {
        SparseBooleanArray arr = listView.getCheckedItemPositions();
        //String str="";
        // gather songs in a to-delete list
        ArrayList<Song> deleteSongs = new ArrayList<Song>();
        for (int i=0; i < arr.size(); i++) {
            if (arr.valueAt(i)) {
                Song song = (Song)listView.getItemAtPosition(
                        arr.keyAt(i));
                //str += song.id + ";";
                deleteSongs.add(song);
            }
        }
        for (Song song: deleteSongs) {
            myList.remove(song);
        }
        listView.setAdapter(new ArrayAdapter<Song>(this, R.layout.song, myList.getSongs()));
        //Toast.makeText(SongLib.this,str,Toast.LENGTH_LONG).show();
    }

    public void addSong() {
        Intent intent = new Intent(this, AddSong.class);
        startActivityForResult(intent, ADD_SONG_CODE);
    }

    public void showSong(int pos) {
        Intent intent = new Intent(this, AddSong.class);

        Song song = myList.getSongs().get(pos);
        Bundle bundle = new Bundle();
        bundle.putString(AddSong.SONG_NAME,song.name);
        bundle.putString(AddSong.SONG_ARTIST,song.artist);
        bundle.putString(AddSong.SONG_ALBUM,song.album);
        bundle.putString(AddSong.SONG_YEAR,song.year);
        bundle.putInt(AddSong.SONG_ID, song.id);
        intent.putExtras(bundle);

        startActivityForResult(intent, EDIT_SONG_CODE);
    }

    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {

        if (resultCode != RESULT_OK) { return; }

        Bundle bundle = intent.getExtras();
        if (bundle == null) { return; }

        String name = bundle.getString(AddSong.SONG_NAME);
        String album = bundle.getString(AddSong.SONG_ALBUM);
        String artist = bundle.getString(AddSong.SONG_ARTIST);
        String year = bundle.getString(AddSong.SONG_YEAR);
        int id = bundle.getInt(AddSong.SONG_ID);

        if (requestCode == ADD_SONG_CODE) {
            myList.add(name, artist, album, year);
        } else if (requestCode == EDIT_SONG_CODE) {
            Song song = new Song(id, name, artist, album, year);
            if (bundle.getBoolean(AddSong.SONG_DELETE)) {
                myList.remove(song);
            } else {
                myList.update(song);
            }
        }

        listView.setAdapter(
                new ArrayAdapter<Song>(this,
                        R.layout.song, myList.getSongs()));

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_search_menu,menu);


        // Get the SearchView and set the searchable configuration
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        MenuItem menuItem = menu.findItem((R.id.action_search));

        if (menuItem == null) {
            Toast.makeText(this, "No menu item!", Toast.LENGTH_LONG).show();
            return false;
        }

        SearchView searchView = (SearchView)menuItem.getActionView();

        /*
        SearchView searchView = (SearchView) menu.findItem(R.id.action_search).getActionView();
        */

        if (searchView == null) {
            Toast.makeText(this, "No search view!", Toast.LENGTH_LONG).show();
            return false;
        }


        // Assumes current activity is the searchable activity
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setIconifiedByDefault(false); // Do not iconify the widget; expand it by default


        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                addSong();
                return true;

            case R.id.action_search:

                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    protected void onNewIntent(Intent intent) {
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query =
                    intent.getStringExtra(SearchManager.QUERY);
            showSearchResults(query);
        } else {
            showSongList();
        }
    }

    private void showSongList() {
        listView.setAdapter(
                new ArrayAdapter<Song>(this, R.layout.song,myList.getSongs()));
        listView.setSelection(lastPickedIndex);

        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        showSong(i);
                    }
                }
        );

    }

    private void showSearchResults(String query) {
        int[] extent = myList.search(query);
        // if no matches, show dialog
        if (extent == null || extent.length == 0) {
            String msg = getString(R.string.search_empty, new Object[] {query});
            Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
            return;
        }

        // make an array of song names for match set and show
        showResultList(extent);

        // set up listener for user tap on selected song
        searchListStartPos = extent[0];
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> parent,
                                            View view, int position,
                                            long id) {
                        lastPickedIndex =
                                SongLib.this.searchListStartPos+position;
                        showSongList();

                    }
                });
    }

    private void showResultList(int[] extent) {
        int count = extent[1] - extent[0] + 1;
        String[] matches = new String[count];
        ArrayList<Song> songs = myList.getSongs();
        for (int i=0; i < matches.length; i++) {
            matches[i] = songs.get(extent[0]+i).name;
        }
        listView.setAdapter(
                new ArrayAdapter<String>(this, R.layout.song, matches));
    }
}
