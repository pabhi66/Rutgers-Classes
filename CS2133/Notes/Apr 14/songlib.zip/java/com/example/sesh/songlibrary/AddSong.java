package com.example.sesh.songlibrary;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.app.DialogFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddSong extends AppCompatActivity {

	public static final String SONG_ID = "songID";
	public static final String SONG_NAME = "songName";
	public static final String SONG_ARTIST = "songArtist";
	public static final String SONG_ALBUM = "songAlbum";
	public static final String SONG_YEAR = "songYear";
	public static final String SONG_DELETE = "songDelete";
	
	EditText songName, songArtist, songAlbum, songYear;
	int songId;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_song);

		Toolbar toolbar = (Toolbar)findViewById(R.id.my_toolbar);
		setSupportActionBar(toolbar);

		ActionBar ab = getSupportActionBar();
		ab.setDisplayHomeAsUpEnabled(true);

		songName = (EditText)findViewById(R.id.song_name);
		songArtist = (EditText)findViewById(R.id.song_artist);
		songAlbum = (EditText)findViewById(R.id.song_album);
		songYear = (EditText)findViewById(R.id.song_year);

		// check if Bundle was passed, and populate fields
		Bundle bundle = getIntent().getExtras();
		songId = -1;
		if (bundle != null) {
			songId = bundle.getInt(SONG_ID);
			songName.setText(bundle.getString(SONG_NAME));
			songArtist.setText(bundle.getString(SONG_ARTIST));
			songAlbum.setText(bundle.getString(SONG_ALBUM));
			songYear.setText(bundle.getString(SONG_YEAR));
		}
		
	}

	// called when the user taps the Save button
	public void save(View view) {
		// gather all data
		String name = songName.getText().toString();
		String artist = songArtist.getText().toString();
		String album = songAlbum.getText().toString();
		String year = songYear.getText().toString();
		
		// name and artist are mandatory
		if (name == null || name.length() == 0 ||
				artist == null || artist.length() == 0) {
			/*
			Toast
			.makeText(this, "Name and Artist are required", Toast.LENGTH_SHORT)
			.show();
			*/

			DialogFragment newFragment = new SongInfoDialogFragment();
			Bundle bundle = new Bundle();
			bundle.putString(SongInfoDialogFragment.MESSAGE_KEY,
							"Name and Artist are required");
			newFragment.setArguments(bundle);
			newFragment.show(getFragmentManager(),"missing fields");

			return;   // does not quit activity, just returns from method
		}
		
		// make Bundle
		Bundle bundle = new Bundle();
		bundle.putString(SONG_NAME,name);
		bundle.putString(SONG_ARTIST,artist);
		bundle.putString(SONG_ALBUM,album);
		bundle.putString(SONG_YEAR,year);
		bundle.putInt(SONG_ID, songId);
		
		// send back to caller
		Intent intent = new Intent();
		intent.putExtras(bundle);
		
		setResult(RESULT_OK,intent);
		finish(); // pops the activity from the call stack, returns to parent
	}
	
	// called when the user taps the Cancel button
	public void cancel(View view) {
		setResult(RESULT_CANCELED);
		finish();
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		if (songId != -1) {
			getMenuInflater().inflate(R.menu.delete_menu, menu);
		}
		return super.onCreateOptionsMenu(menu);
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.action_delete:
				deleteSong();
				return true;
			default:
				return super.onOptionsItemSelected(item);

		}
	}

	public void deleteSong() {
		Bundle bundle = new Bundle();

		bundle.putString(SONG_NAME,songName.getText().toString());
		bundle.putString(SONG_ARTIST,songArtist.getText().toString());
		bundle.putString(SONG_ALBUM,songAlbum.getText().toString());
		bundle.putString(SONG_YEAR,songYear.getText().toString());
		bundle.putInt(SONG_ID, songId);
		bundle.putBoolean(SONG_DELETE,true);


		Intent intent = new Intent();
		intent.putExtras(bundle);

		setResult(RESULT_OK,intent);
		finish();
	}

}
