package com.example.sesh.songlibrary;

public class Song implements Comparable<Song> {
	public int id;
	public String name;
	public String artist;
	public String album;
	public String year;
	
	public Song(int id, String name, String artist, String album, String year) {
		this.id = id;
		this.name = name;
		this.artist = artist;
		this.album = album;
		this.year = year;
	}
	
	public int compareTo(Song other) {

		return name.compareToIgnoreCase(other.name);
	}
	
	public String toString() {   // this is for ListView adapter

		return name + "\n(" + artist + ")";
	}
	
	public String getString() {

		return name + ":" + artist + ":" + album + ":" + year;
	}

	// this is only for use by parseSong
	private Song() { }

	public static Song parseSong(String songInfo) {
		String[] tokens = songInfo.split(":");
		Song song = new Song();
		song.id = -1;
		song.name = tokens[0];
		song.artist = tokens[1];
		song.album = "";
		song.year = "";
		if (tokens.length > 2) {
			song.album = tokens[2];
		}
		if (tokens.length > 3) {
			song.year = tokens[3];
		}
		return song;
	}
}
