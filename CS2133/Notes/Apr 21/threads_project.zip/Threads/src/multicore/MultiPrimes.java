package multicore;
import java.util.Arrays;
import java.util.Scanner;

public class MultiPrimes implements Runnable {
	
	Thread myThread;
	int count;
	int start, end;
	
	public MultiPrimes(int start, int end) {
		count = 0;
		this.start = start;
		this.end = end;
		myThread = new Thread(this);
		myThread.start();
	}
	
	public void run() {
		int p=start;
		while (!Thread.interrupted() && p <= end) {
			int d;
			for (d=2; d <= p/2; d++) {
				if ((p%d) == 0) {
					break;
				}
			}
			if (d > p/2) {
				count++;
			}
			p++;
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter n: ");
		int n = Integer.parseInt(sc.nextLine());
		
		// ask for number of threads
		System.out.print("How many threads? (quit to stop): ");
		String line = sc.nextLine();
		while (!"quit".equals(line)) {
			int t = Integer.parseInt(line);
			t = Math.min(t, Runtime.getRuntime().availableProcessors());
			MultiPrimes[] primeRuns = new MultiPrimes[t];
			
			// how to apportion range
			System.out.print("Proportion: ");
			int div = Integer.parseInt(sc.nextLine());

			// divvy up work
			class Slice {
				int start;
				int end;
				public String toString() {
					return "[" + start + ":" + end + "]";
				}
			}
			Slice[] slices = new Slice[t];
			int lo=2;
			for (int i=0; i < (t-1); i++) {
				slices[i] = new Slice();
				slices[i].start = lo;
				int hi = lo+n/t-1;
				if (div != 1) {
					hi = lo + (n-lo)*(div-1)/div;
				}
				slices[i].end = hi;
				lo = hi + 1;
			}
			// rest for last
			slices[t-1] = new Slice();
			slices[t-1].start = lo;
			slices[t-1].end = n;
			
			System.out.println(Arrays.toString(slices));
			
			// TIME IT
			long begin = System.currentTimeMillis();
			for (int i=0; i < t; i++) {
				primeRuns[i] = new MultiPrimes(slices[i].start,slices[i].end);
			}

			// wait on all of them to finish
			int allPrimes=0;
			for (int i=0; i < t; i++) {
				try {
					primeRuns[i].myThread.join();
					allPrimes += primeRuns[i].count;
				} catch (InterruptedException e) {

				}
			}
			long end = System.currentTimeMillis();
			System.out.println("Total number of primes = " + allPrimes
					+ ", took " + (end-begin) + " milliseconds");

			
			System.out.print("\nHow many threads? (quit to stop): ");
			line = sc.nextLine();
		}
	}

}
