package animation;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BouncingBall extends JFrame implements ActionListener {
	
	public static final int delay = 100;
	
	private JButton slower, faster, stop, start;
	private Animator animPanel;
	
	public BouncingBall(String title) {
		super(title);
		animPanel = new Animator(delay);
		JPanel controlPanel = new JPanel();
		
		slower = new JButton("Slower");
		stop = new JButton("Stop");
		start = new JButton("Start");
		faster = new JButton("Faster");
		
		stop.addActionListener(this);
		start.addActionListener(this);
		slower.addActionListener(this);
		faster.addActionListener(this);
		
		controlPanel.add(slower);
		controlPanel.add(stop);
		controlPanel.add(start);
		controlPanel.add(faster);
		
		add(animPanel, BorderLayout.CENTER);
		add(controlPanel, BorderLayout.SOUTH);
		
		animPanel.start();
	}
	
	public void actionPerformed(ActionEvent e) {
		JButton button = (JButton)e.getSource();
		if (button == slower) {
			animPanel.slower();
		} else if (button == faster){
			animPanel.faster();
		} else if (button == start) {
			animPanel.start();
		} else {
			animPanel.stop();
		}
	}

	public static void main(String[] args) {
		JFrame frame = new BouncingBall("Bouncing Ball");
		frame.pack();
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}


