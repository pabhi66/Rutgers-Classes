package calc.view;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

/**
 * This class acts as listener for all events fired from the calculator buttons.
 * It keeps track of the current state instance of the calculator model.
 * When an event is handled by the controller, it delegates event processing
 * to the current state instance, which processes the event and returns the next
 * state.
 * When the calculator starts up, it is set to the clear state.
 * 
 * @author Sesh Venugopal
 */
public class CalcController {
	
	/**
	 * The clear state.
	 */
	protected CalcClearState calcClearState; 
	
	/**
	 * The first operand integer state.
	 */
	protected CalcOp1IntState calcOp1IntState;
	
	/**
	 * The first operand floating point state. 
	 */
	protected CalcOp1FloatState calcOp1FloatState;
	
	/**
	 * The second operand integer state.
	 */
	protected CalcOp2IntState calcOp2IntState;
	
	/**
	 * The second operand floating point state. 
	 */
	protected CalcOp2FloatState calcOp2FloatState;
	
	/**
	 * The operator state. 
	 */
	protected CalcOperatorState calcOperatorState;
	
	/**
	 * The equals state. 
	 */
	protected CalcEqualsState calcEqualsState;
	
	/**
	 * The operator, when it is entered
	 */
	protected String operator;
	
	/**
	 * The first operand
	 */
	protected double opnd1;
	
	@FXML
	protected TextField display;
	
	@FXML
	protected DigitController digitsController;
	
	@FXML
	protected OperatorController opsController;
	
	@FXML
	protected ResultController resController;
	
	/**
     * Current state instance
     */
    protected CalcState currentState;
    
    /**
     * Starts up the state machine in clear state.
     */
    public void start() {
    		// set up the view controllers
    		digitsController.setCalcController(this);
    		opsController.setCalcController(this);
    		resController.setCalcController(this);

    		// set the display to 0
    		display.setText("0");

    		// make the states
    		calcClearState = CalcClearState.getInstance(this);
    		calcOp1IntState = CalcOp1IntState.getInstance(this);
    		calcOp1FloatState = CalcOp1FloatState.getInstance(this);
    		calcOp2IntState = CalcOp2IntState.getInstance(this);
    		calcOp2FloatState = CalcOp2FloatState.getInstance(this);
    		calcOperatorState = CalcOperatorState.getInstance(this);
    		calcEqualsState = CalcEqualsState.getInstance(this);
    				
    		// get the machine up and running
    		currentState = calcClearState;
    		currentState.enter();
    }
    
    /**
     * Process event fired from any of the buttons
     * 
     * @param e The action event that is to be passed on for handling.
     */
    public void processEvent(ActionEvent e) {
        CalcState.lastEvent = e; 
        currentState = currentState.processEvent();
    }
    
	public void doOperator(String operator) {
		this.operator = operator;
        opnd1 = Double.parseDouble(display.getText());
        display.setText("0.0");
        // re-enable decimal point                                             
        digitsController.enableDecimal();
	}

	public void doDigit(char c) {
		// if current value is zero, replace with this value                   
        // otherwise append                                                    
		if ((Double.parseDouble(display.getText()) == 0) && 
				(Character.isDigit(c))) {
			display.setText(""+Character.digit(c,10));
		} else {
			display.appendText(""+c);
		}
		// if decimal point, deactivate decimal button                         
		if (c == '.') {
			digitsController.disableDecimal();
		}
	}
	
	public void doResult() {
		double opnd2 = Double.parseDouble(display.getText());
        opnd1 = compute(opnd2);
        display.setText(""+opnd1);
        // re-enable decimal point                                             
        digitsController.enableDecimal();
	}
	
	public void doClear() {
		opnd1 = 0.0;
        display.setText(""+opnd1);
	}
	
	protected double compute(double opnd2) {
		char ch = operator.charAt(0);
        switch (ch) {
        	case '+': return opnd1 + opnd2;
        	case '-': return opnd1 - opnd2;
        	case '*': return opnd1 * opnd2;
        	case '/': return opnd1 / opnd2;
        	default: return 0;
        }
	}
	
}
