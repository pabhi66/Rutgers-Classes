#ifndef SORTED_LIST_H
#define SORTED_LIST_H
typedef int (*CompareFuncT)(void *, void *);
/*this struct is used to create the node
*/
struct node
{
		char *file;/*this is the name of file*/
		int freq;/*freq of the token*/
		struct node * next;/*pointer to the next node containing the filename and freq*/
};

typedef struct token *token_t;
/*this struct is used to create the list of node which has tokens in it
*/
struct token
{
	char * term;/*token name*/
	token_t  nexttoken;/*pointer to next token in token list*/
	struct node *nextfile;/*pointer to the filename and freq list for every token node*/
};

/*this is used to create the list*/
struct SortedList
{	 
	 struct node *headfile;
	 token_t headtoken;/*points to the first token in token list*/
	 CompareFuncT com;
	 
};
typedef struct SortedList* SortedListPtr;
/*this is used to create the iterator object*/
struct SortedListIterator
{
	token_t head;
};
typedef struct SortedListIterator* SortedListIteratorPtr;

/*This  method is used to create the list pointer
* This will return the SortedListPtr object
*/
SortedListPtr SLCreate(CompareFuncT cf);

/*This method is used to insert token into the list
it takes three parameters list, filename which is being read and the token
*/
int SLInserttoken(SortedListPtr list, char *newObj,char *filename);


/*this method is used to sort the list which has filename and freq of the token
*/
struct node *sort_list(struct node *head);

/*this is used to insert the filename and freq
this takes struct token object and filename
*/
int SLInsertfile(token_t rightlist, char *newObj);

/*this method will create the iterator object*/
SortedListIteratorPtr SLCreateIterator(SortedListPtr list);

/*this method is used to iterate through the list*/
char * iterator(SortedListIteratorPtr iter);

/*this will delete the list object*/
void SLDelete(SortedListPtr s);

/*this will delete the iterator object*/
void SLIterator(SortedListIteratorPtr i);

void freememory(char * f);

/*This will deallocate the memory used by the entire list*/
int deleteList(SortedListPtr deletelist);


#endif
