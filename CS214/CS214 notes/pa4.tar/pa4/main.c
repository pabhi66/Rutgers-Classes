#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "search.h"
#include "searchsorted-list.h"
#include "tokenizer.h"
int compareString(void *p1, void *p2)
{
	char *s1 = p1;
	char *s2 = p2;

	return strcmp(s1, s2);
}


/*this method asks the user to enter the queries*/
void user(SortedListPtr l)
{
	char * end=(char *)malloc(sizeof(char));
	printf("\"sa\" will search with and, \"so\" will search with or\n");
	do
	{
		printf("Enter sa followed by terms to search for,  Enter so followed by terms to search for, enter q for quit\n\n");
		scanf("%[^\n]", end);
		getchar();
		TokenizerT* t = TKCreate(" ",end);
		char * string=TKGetNextToken(t);/*string contains sa or so or q*/
		if(strcasecmp(string,"sa")==0 )
		{
			separatelist(l,end);		
		}
		else if(strcasecmp(string,"so")==0)
		{
			separatelist(l,end);
		}
		else if(strcasecmp(string,"q")==0)
		{
			printf("Program exit\n");
			exit(0);
		}
		else
		{
			printf("you need to enter first sa, so or q\n");
		}
	}while(strcasecmp(end,"q")!=0);
	free(end);
}


int main(int argc,char ** argv)
{
	if(argc==2)
	{
		int (*functionptr)(void *,void*);
		functionptr=&compareString;/*function pointer to comparestring*/
		SortedListPtr sl=SLCreate(functionptr);/*creates the object of list*/
		struct stat s;
		if( stat(argv[1],&s) == 0 )/*if the given file or directory's path is right*/
		{
		
			if( s.st_mode & S_IFDIR)/*if it is a directory*/
			{
				printf("No directory should be given in the argument\n");
				exit(0);
				
			}	
			else if( s.st_mode & S_IFREG )/*if the reading file is a file*/
			{
				FILE * open;
				open=fopen(argv[1],"r");/*open the file to read*/
				if(open!=NULL)/*if the file exist*/
				{
					storedata(open,sl);/*calls the storedata to store the file contain into the data structure*/
					user(sl);/*calls the user method for the queries*/
					SLDelete(sl);
					deleteList(sl);
				
				
				}
			}
		}
		else/*if the path to read the files is not right*/
		{
			printf("error in opening directory or file. The path is not proper\n");
			return 0;
		}
	}
	else/*if 2 arguments are not given*/
	{
		printf("You need to give exactly two arguments\n");
		exit(1);
	}
			return 0;
}
