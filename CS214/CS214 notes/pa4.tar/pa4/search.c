#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "searchsorted-list.h"
#include "tokenizer.h"
int compareString1(void *p1, void *p2)
{
	char *s1 = p1;
	char *s2 = p2;

	return strcmp(s1, s2);
}

void storedata(FILE *fp,SortedListPtr slfile)
{
	char * line = NULL;
	size_t len = 0;
	ssize_t read;
	int empty=0;
	while ((read = getline(&line, &len, fp)) != -1) /*reads the line from the file*/
	{
		empty++;
		TokenizerT* tokenizer = TKCreate("<>\n\" ",line);
		TKGetNextToken(tokenizer);/*returns the token from the file*/
		char * stoken=TKGetNextToken(tokenizer);/*stoken will contain the token*/
		getline(&line, &len, fp);
		while (strcmp(line,"</list>\n")!=0 && read!=-1 ) /*get the line until do not find </list>*/
		{
			 TokenizerT*tok = TKCreate("\n ",line);
			 char * file=TKGetNextToken(tok);/*returns the filename from the file*/
			char * freq=TKGetNextToken(tok);/*returns the freq from the file*/
		
			while(file!=NULL)/*until there is filename in the file*/
			{
				SLInserttoken(slfile,stoken,file,freq);/*insert the filename and freq into the list*/
				file=TKGetNextToken(tok);
			    freq=TKGetNextToken(tok);
			    	
			}
			read=getline(&line, &len, fp);/*reads the next line*/
		}
	}
	if(empty==0)/*if there is nothing in the file*/
	{
		printf("Empty file\n");
		exit(0);
	}
	
}
void searchandfile(SortedListPtr slist,int c);
void searchorfile(SortedListPtr orlist,int c);

/*this method creates the another linked list structure
 * but this linked list hase only the queries user provided
 * this store the queries and its file from the main linked list structure
 */
 
void separatelist(SortedListPtr sl,char * s)
{
	int count=0;/*number of tokens in the list*/
	int nottoken=0;/*used for sa, the token is not in the list, it does not increment*/
	int orcount=0;/*to count how many tokens are in the list for so*/
	int tokeninside=0;
	int (*functionptr)(void *,void*);
	functionptr=&compareString1;
	SortedListPtr search=SLCreate(functionptr);
	TokenizerT* t = TKCreate(" ",s);
	char * word=TKGetNextToken(t);/*word will store sa or so depending on user query*/
	char * string=TKGetNextToken(t);/*this is query*/
	while(string!=NULL)
	{
		
		nottoken=0;
		token_t cur=sl->headtoken;
		/*while loop which will go thorugh the main data strucutre
		 * which has all the tokens stored from the file*/
		 
		while(cur!=NULL && strcmp(cur->term,string)<=0)
		{
			 if(string!=NULL)
			{
				token_t tcheck=search->headtoken;
				/*this while loop is used when user gives two same queries
				 * we do not want to store same query twice in the list
				 * therefore it will check for the each query
				 * and the query is already in the list
				 * then it will not store it again*/
				while(tcheck!=NULL)
				{
					if(strcmp(tcheck->term,string)==0)
					{
						tokeninside++;
						break;
					}
					else
					{
						tcheck=tcheck->nexttoken;
					}
				}
			}
			if(tokeninside>0)
			{
				tokeninside=0;
				nottoken=1;
				count--;
				break;
			}
			if(strcmp(string,cur->term)==0)/*if the token is found*/
			{
				nottoken++;/*increase the nottoken*/
				orcount++;//if the token in the list increments orcount*/
				struct node *n=cur->nextfile;/*n will point to the file list pointer*/
				while(n!=NULL)
				{
					SLInserttoken(search,string,n->file,n->freq);/*this will store the token and string into this new data structure*/
					n=n->next;
				}
				break;
			}
			else/*if the token is not found, increment the token pointer*/
			{
				cur=cur->nexttoken;
			}
			
		}
		if(nottoken==0 && strcasecmp(word,"so")==0)
		{
			printf("This query :  %s  : is not in the database\n",string);
		}
		string=TKGetNextToken(t);/*take the next string using tokenizer*/
		if(nottoken==0 && strcasecmp(word,"sa")==0)/*if nottoken is 0 which means the token is not inside the list and user query is sa*/
		{
			if(strcasecmp(word,"sa")==0)/*if the nottoken is 0 which means one token is not the list
			                          which means we will not have any file which hase all the token*/
			{
				printf("atleast one query is not in the list so there is no file which has every query\n\n");
				count++;
				break;
			}
			
		}
		else
		{
			count++;
			if(string!=NULL)
			{
				token_t tcheck=search->headtoken;
				/*this while loop is used when user gives two same queries
				 * we do not want to store same query twice in the list
				 * therefore it will check for the each query
				 * and the query is already in the list
				 * then it will not store it again*/
				while(tcheck!=NULL)
				{
					if(strcmp(tcheck->term,string)==0)
					{
						string=TKGetNextToken(t);
						break;
					}
					else
					{
						tcheck=tcheck->nexttoken;
					}
				}
			}
		}
	}
	if(nottoken!=0)
	{
		if(strcasecmp(word,"sa")==0)
		{
			searchandfile(search,count);
		}
		if(strcasecmp(word,"so")==0)
		{
			searchorfile(search,count);
		}
		deleteList(search);
		SLDelete(search);
	}
	else if(nottoken==0 && count>1 && strcasecmp(word,"sa")==0)/*nottoken is 0 which means there is no file*/
	{
		deleteList(search);
		SLDelete(search);
	}
	else if(strcasecmp(word,"so")==0 && orcount>=0)/*this will check for the OR queries*/
	{
		if(orcount==0)/*if all the queries is not in the list*/
		{
				if(count==0)/*if user does not enter any query*/
				{
					printf("You need to give atleast one query to search\n\n");
				}
				else/*user enter the queries but there is no query in the list*/
				{
					printf("no query is in the list\n\n");
					SLDelete(search);
				}
		}
		else/*if atleast one query is in the list*/
		{
			searchorfile(search,count);
			deleteList(search);
			SLDelete(search);
		}
	}
	else if(count==0)/*if user does not enter the query*/
	{
		printf("You need to give atleast one query to search for\n\n");
	}
	
}

/* This method will search the fileneams when the user give queries with 
 * logical or
 * it will print the filenames for each query because it is OR*/
void searchorfile(SortedListPtr orlist,int c)
{
	struct node * f=orlist->headtoken->nextfile;
	token_t d=orlist->headtoken;
	char * s=f->file;
	if(c==1)/*if only one query is given*/
	{
		while(f!=NULL)
		{
			s=f->file;
			printf("Files are: %s\n ",s);/*print the filenames for that query*/
			f=f->next;
		}
		printf("\n");
	}
	else/*print the filename for all queries which contains in the list*/
	{
		while(d!=NULL)
		{
			printf("Token is: %s\n",d->term);
			f=d->nextfile;
			while(f!=NULL)
			{
				printf("Files are : %s\n",f->file);
				f=f->next;
			}
			d=d->nexttoken;
			
		}
		printf("\n");
	}
}
/* This method will search the fileneams when the user give queries with 
 * logical and
 * If there is one or more files that has all the queries,
 * it will print the filename*/
void searchandfile(SortedListPtr slist,int c)
{
	int mycount=0;
	struct node * f=slist->headtoken->nextfile;/* f will point to the file list*/
	token_t d=slist->headtoken;/*d will point to the first token*/
	char * s=f->file;/*s is the first filename for the first token*/
	int nofile=0;/*nofile to check if atleast one file which contains all queries*/
	if(c==1)/*if user enter only one query*/
	{
		while(f!=NULL)
		{
			s=f->file;
			printf("File is : %s\n ",s);/*prints the file for that query*/
			f=f->next;
		}
		printf("\n");
	}
	else/*if there is more than one query*/
	{
		while(f!=NULL)
		{
			s=f->file;
			d=slist->headtoken;
			d=d->nexttoken;/*d will point to nexttoken*/
			while(d!=NULL)
			{
			
				struct node * n1=d->nextfile;/*n1 will point to file list for the d*/
				while(n1!=NULL)
				{
					if(strcmp(n1->file,s)==0)/*if the filename matches with the firsttoken file*/
					{
						mycount++;
						break;
					}
					else
					{
						n1=n1->next;
					}
				}
				if(mycount==0)/*if there is no file matches the file for the nexttoken*/ 
				{	
					break;/*it will break the loop and go to the nextfile for first token*/
				}
				d=d->nexttoken;
			}
			if(mycount==c-1)/*when mycount==c-1 which means there is a file which is in the all queries given*/
			{
				printf("File is %s\n",s);
				nofile++;
			}
			mycount=0;
			f=f->next;/*take the nextfile of first token*/
		}
		if(nofile==0)
		{
			printf("No file contains all the query\n");
		}
		printf("\n");
	}
}



