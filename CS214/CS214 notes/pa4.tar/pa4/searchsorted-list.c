#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "searchsorted-list.h"

/*this method creates the list object*/
SortedListPtr SLCreate(CompareFuncT cf)
{
	SortedListPtr s1 = (struct SortedList*)malloc(sizeof(struct SortedList));/*create memory for the struct SortedList object*/
    s1->com = cf;/*assign compareFuncT object to struct member*/
    s1->headtoken=NULL;/*create null list*/
    return s1;
}
/*This method insert the token into the list 
 * then it will call SLInsertfile method
 * which will store the file and freq for that token
 * newObj is the token, filename is file and fr is the freq
 */
int SLInserttoken(SortedListPtr list, char *newObj,char *filename,char * fr)
{
  token_t new;
  new = (struct token*)malloc(sizeof(struct token));/*allocate memory for new node*/
  new->term=newObj;
  new->nexttoken=NULL;
  new->nextfile=NULL;
  if(list->headtoken==NULL)/*if the list is empty*/ 
  {
	  list->headtoken=new;/*insert the first node and give the headtoken pointer to that node*/
	  SLInsertfile(list->headtoken,filename,fr);/*call insertfile method to store the filename and freq for that token*/
	  return 1;
  }
  else/*if the list is not empty*/
  {
	  token_t cur=list->headtoken;
	  while(cur->nexttoken!=NULL)/*traverse through the end of list*/
	  {
		  cur=cur->nexttoken;
	  }
	  if(strcmp(cur->term,newObj)==0)/*if the token is already saved in the list*/
	  {
		SLInsertfile(cur,filename,fr);/*call the SLInsertfile to store the filename and freq*/
	  }
	  else/*if the token is not in the list*/
	  {
		  cur->nexttoken=new;
		  SLInsertfile(cur->nexttoken,filename,fr);
		  
	  }
  }
	return 0;
}
 
/*this method insert the filename and its freq for that token
 * if the filename already exist then it will increase the freq and call sort_list method
 * to sort the list according to freq*/
int SLInsertfile(token_t rightlist, char *newObj,char * fr)
{
  struct node* new;
  new = (struct node*)malloc(sizeof(struct node));/*allocate memory for new node*/
  new->file=newObj;/*store the filename and its freq for that token*/
  new->freq=fr;
  new->next=NULL;
  if(rightlist->nextfile==NULL)/*if the new token is inserted*/
  {
	  
	  rightlist->nextfile=new;
	  return 1;
	}
	else
	{
		struct node*cur=rightlist->nextfile;
		while(cur->next!=NULL)/*traverse to the end of file*/
		{
			cur=cur->next;
		}
		cur->next=new;/*add the filename and freq*/
	}
	return 0;
}
void freememory(char * f)
{
	free(f);
	f=NULL;
}
/*free the list object*/
void SLDelete(SortedListPtr s)
{
	free(s);
	s=NULL;
}


/*is used to free the nodes of entirelist*/
int deleteList(SortedListPtr deletelist)
{
	
	token_t  temp1=NULL;
	struct node * temp=NULL;
	token_t  tok=deletelist->headtoken;
	struct node * nod=tok->nextfile;
	while(tok!=NULL)/*make token list free*/
	{
		while(nod!=NULL)/*make the filename and freq list free*/
		{
			
			temp=nod;
			nod=nod->next;
			free(temp);
		}
		temp1=tok;
		tok=tok->nexttoken;
		free(temp1);
	}
	return 1;
	
}

