#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "sorted-list.h"
/*this method creates the list object*/
SortedListPtr SLCreate(CompareFuncT cf)
{
	SortedListPtr s1 = (struct SortedList*)malloc(sizeof(struct SortedList));/*create memory for the struct SortedList object*/
    s1->com = cf;/*assign compareFuncT object to struct member*/
    s1->headtoken=NULL;/*create null list*/
    return s1;
}
/*This method insert the token into the list 
 * then it will call SLInsertfile method
 * which will store the file for that token
 * newObj is the token and filename is the name of file that
 * token appears in
 */
int SLInserttoken(SortedListPtr list, char *newObj,char *filename)
{
  token_t new;/*creates node of token_t type*/
  new = (struct token*)malloc(sizeof(struct token));/*allocate memory for new node*/
  new->term=newObj;
  new->nexttoken=NULL;/*token node's pointer for the nexttoken*/
  new->nextfile=NULL;/*token node's pointer for the filename and freq list*/
  if(new)
  {
	if(list->headtoken==NULL)/*if the list is empty*/ 
	{
		list->headtoken=new;/*insert the first node and give the headtoken pointer to that node*/
		SLInsertfile(list->headtoken,filename);/*call insertfile method to store the filename and freq for that token*/
		return 1;
	}
	else/*if the list is not empty*/
	{
		token_t cur=list->headtoken;
		if(list->com(new->term,cur->term)<0)/*if the newobject is smaller than the head of list*/
		{
			new->nexttoken=list->headtoken;/*add new node at the head*/
			list->headtoken=new;
			SLInsertfile(list->headtoken,filename);/*calls insertfile method to store the filename and freq*/
			return 1;
		}
		else if(list->com(new->term,cur->term)==0)/*if the new object is equal*/
		{
		   SLInsertfile(cur,filename);/*as the token already exist in the list, just calls the method to store the filename and freq*/
		   return 1;
		   
		}
		else/*if the new object is bigger than the head*/
		{
			cur=list->headtoken;
			while(list->com(new->term,cur->term)>=0)
			{
				if(cur->nexttoken!=NULL)/*if cur is not pointing to last node*/
				{
				  if(list->com(new->term,cur->nexttoken->term)>0)
				  {
					  cur=cur->nexttoken;/*increase the pointer*/
				  }
				  else if(list->com(new->term,cur->nexttoken->term)==0)
				  {
						SLInsertfile(cur->nexttoken,filename);
						return 1;
				  }
				  else
				  {
					  new->nexttoken=cur->nexttoken;/*add the token node at appropriate place*/
					  cur->nexttoken=new;
					  SLInsertfile(cur->nexttoken,filename);/*calls the method to store filename and freq for that token*/
					 return 1;
				  }
			  }
			  else/*adds the new object to end of list*/
			  {
				  
					cur->nexttoken=new;
					SLInsertfile(cur->nexttoken,filename);
					return 1;
				
			  }
			}
		}
	}
  }
  else
  {
		printf("no memory allocates");
  }
  return 0;
}
/*this method  sort the list which contains the filename and freq data
 * according to freq,highest freq comes first, for each token node
*/
struct node *sort_list(struct node *head) {

    struct node *tmpPtr = head;
    struct node *tmpNxt = head->next;

    int tmp;
	char * temfile;
    while(tmpNxt != NULL){
           while(tmpNxt != tmpPtr){
                    if(tmpNxt->freq > tmpPtr->freq){
                            tmp = tmpPtr->freq;
                            temfile=tmpPtr->file;
                            tmpPtr->freq = tmpNxt->freq;
                            tmpPtr->file=tmpNxt->file;
                            tmpNxt->freq = tmp;
                            tmpNxt->file=temfile;
                    }
                    tmpPtr = tmpPtr->next;
            }
            tmpPtr = head;
            tmpNxt = tmpNxt->next;
    }
         return tmpPtr ;
} 
/*this method insert the filename and its freq for that token
 * if the filename already exist then it will increase the freq and call sort_list method
 * to sort the list according to freq
 * newObj is the name of the file*/
int SLInsertfile(token_t rightlist, char *newObj)
{
  struct node* new;
  new = (struct node*)malloc(sizeof(struct node));/*allocate memory for new node*/

  if(rightlist->nextfile==NULL)/*if the new token is inserted*/
  {
	  new->file=newObj;/*store the filename and its freq for that token*/
	  new->freq=1;
	  new->next=NULL;
	  rightlist->nextfile=new;
	  return 1;
	  
  }
  else/*if the token is already in the list*/
  {
	  struct node *cur=rightlist->nextfile;
	  while(cur!=NULL)
	  {
		  if(strcmp(cur->file,newObj)==0)/*check weather the filename for that token is already in the list*/
		  {
			  (cur->freq)++;/*increase the freq*/
			  rightlist->nextfile=sort_list(rightlist->nextfile);/*calls the sort_list method to sort the list containing the
			                                                      *filename for that token*/
			  return 0;
		  }
		  else
		  {
			 
			  if(cur->next==NULL)/*if the filename for that token does not exist,add the new node for filename and freq*/
			  {
					new->file=newObj;
					new->next=NULL;
					new->freq=1;
					cur->next=new;
					return 1;
					
			  }
			  else/*increase the pointer*/
			  {
				  cur=cur->next;
			  }
		  }
	  }  
  }
	return 0;
}
static int check;//this is used to see weather the iterator has to return head data of the token list*/
/*creates the iterator object*/
SortedListIteratorPtr SLCreateIterator(SortedListPtr list)
{
	SortedListIteratorPtr sptr=malloc(sizeof(SortedListIteratorPtr));
	sptr->head=list->headtoken;/*give the head of list to sptr's head*/
	check=1;
	return sptr;   
}
static struct node* temp;/*is used to iterat through the list which contains filename and freq*/
/*iterat through the list of tokens and filenames list*/
char * iterator(SortedListIteratorPtr iter)
{
	char* object1;
	char *tmp;
	
	if(iter->head!=NULL)
	{
		
		if(check==1)/*when check==1 it returns the token*/
		{
			char * object=iter->head->term;
			temp=iter->head->nextfile;/*point temp to filename list for that token*/
			check++;
			
			return object;
		}
		else/*returns the filename and freq fir that token*/
		{
			if(temp!=NULL)
			{
					object1=temp->file;/*store the filename into object1*/
					char buffer[10];
					sprintf(buffer,"%d",(temp->freq));
					tmp=malloc(sizeof(char)*(strlen(object1)+strlen(buffer)+1));
					strncat(tmp,object1,strlen(object1));
					strncat(tmp," ",1);
					strncat(tmp,buffer,strlen(buffer));/*tmp contains the string of filename and freq*/
					temp=temp->next;
					if(temp==NULL)/*if the temp is point to the last node of filename list*/
					{
						iter->head=iter->head->nexttoken;/*make token's pointer point to the next token*/
					}
					return tmp;
					
			}
			else/*return null and make check=1, so that for next call the iter returns the nexttoken*/
			{
				check=1;
				return NULL;
			}
			
		}
	}
	return NULL;
}

void freememory(char * f)
{
	free(f);
	f=NULL;
}
/*free the list object*/
void SLDelete(SortedListPtr s)
{
	free(s);
	s=NULL;
}
/*free the iterator object*/
void SLIterator(SortedListIteratorPtr i)
{
	free(i);
	i=NULL;
}

/*is used to free the nodes of token list and filename,freq list*/
int deleteList(SortedListPtr deletelist)
{
	
	token_t  temp1=NULL;
	struct node * temp=NULL;
	token_t  tok=deletelist->headtoken;
	struct node * nod=tok->nextfile;
	while(tok!=NULL)/*this loop make token list free*/
	{
		while(nod!=NULL)/*this loop make the filename and freq list free*/
		{
			
			temp=nod;
			nod=nod->next;
			free(temp);
		}
		temp1=tok;
		tok=tok->nexttoken;/*point to the nexttoken node*/
		free(temp1);
	}
	return 1;
	
}
