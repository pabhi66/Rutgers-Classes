#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "sorted-list.h"
#include "tokenizerindex.h"

int compareString(void *p1, void *p2)
{
	char *s1 = p1;
	char *s2 = p2;

	return strcmp(s1, s2);
}
int storefile(FILE * ,char * ,SortedListPtr);
/*this is used when the directory path is given to read the files
 * this will traverse the directory
 * opening each and every file
 * calls the storefile method after reading one file
 * which will open the file and store the data into the list*/
void traverse_dir(DIR * od, const char *dir_name,SortedListPtr sl)
{
     struct dirent *fname;
     char *t;
	od=opendir(dir_name);/*opens the directory*/
	if(od != NULL)
    {
        while((fname = readdir(od)) != NULL)/*reads the directory*/
        {
			if((strcmp(fname->d_name, ".") != 0) && (strcmp(fname->d_name, "..") != 0))/*ignores the hidden folders*/
            {
                 if(fname->d_type == DT_DIR)/*if there is subdirectory into a directory*/
                 {
                     t = (char *)malloc(strlen(dir_name) + strlen(fname->d_name) + 2);
                     strcpy(t, dir_name);/*copy the directory name to t*/
                     strcat(t, "/");
                     strcat(t, fname->d_name);/*copy the sub directory name to t*/
					 traverse_dir(od,t,sl);/*give the full pathname to recurse to travers_dir*/
                    
                  }
				  if(fname->d_type == DT_REG)/*if the directory has a file*/
                  {
                      t = (char *)malloc(strlen(dir_name) + strlen(fname->d_name) + 2);
                      strcpy(t, dir_name);
                      strcat(t, "/");
                      strcat(t, fname->d_name);/*copy the whole path of that file and store into t*/
					 
					  FILE * fp;
					  fp = fopen(t, "r");/*opens the file*/
					  storefile(fp,t,sl); /*pass the FILE *, filename to storefile to read and store data*/  
				   }	
					
				} 
		}
		
	}
}
/*this method is used to print the data into the given write file
 * writefile is argument for the file to write*/
void printfile(SortedListPtr slprint,char * writefile)
{
	SortedListIteratorPtr i=SLCreateIterator(slprint);
	char* string=iterator(i);/*calls the iterator  method*/
	int count=0;
	FILE *fp;
	fp=fopen(writefile,"w");/*open the file to write*/
	
	
	if(fp!=NULL )/*if the path is right*/
	{
		while(string!=NULL)/*while loop goes until the token list's last object is not returned*/
		{
			/*print the store data into the file*/
			fprintf(fp,"<list>");
			fprintf(fp,"%s",string);
			char* filename=iterator(i);/*calls the iterator method to get the filename and freq*/
			fprintf(fp,"\n");
			while(filename!=NULL)/*while loop goes until the filename list's last object for the token is not returned*/
			{
				if(count<5)/*if the count is less than 5 then prints the data on one line*/
				{
					fprintf(fp,"%s   ",filename);
					freememory(filename);
					filename=iterator(i);
					count++;
				}
				else/*if the count goes to 5 then make the count 0 and add the newline*/
				{
					count=0;
					fprintf(fp,"\n");
				
				}
			}
			count=0;
			fprintf(fp,"\n</list>\n");
			string=iterator(i);/*calls the iterator to get the nexttoken*/
		}	
		
	
		SLIterator(i);/*free the iterator object*/
		fclose(fp);/*close the file*/
	}
	else/*if the path is wrong*/
	{
		printf("Can't open output file %s %s!\n",
          writefile," Either it is a directory or the path is wrong");
	}
}
static int check=0;/*this int will be used to check weather the file has something to read*/		
/*this method is used to store the data into the data structure*/					
int storefile(FILE * fp,char * file,SortedListPtr slfile)
{
	char * line = NULL;
	size_t len = 0;
	ssize_t read;
	if (fp == 0)
	{
		printf("error\n");
		return 0;
	}
	else/*reads the line by line*/
	{
     	while ((read = getline(&line, &len, fp)) != -1) 
		{
			
			TokenizerT* tokenizer = TKCreate(line);
			char * s=TKGetNextToken(tokenizer);/*returns the token from the file*/
			check++; /*increase the check when there is something to read*/
			while(s!=NULL)
			{
				
				SLInserttoken(slfile,s,file);/*calls the SLInserttoken to store the token into list*/
				s=TKGetNextToken(tokenizer);/*get the next token*/
			}
		}
	}
	return 1;
}
int main(int argc,char ** argv)
{	 
	DIR *od;
	int (*functionptr)(void *,void*);
	functionptr=&compareString;/*function pointer to comparestring*/
	SortedListPtr sl=SLCreate(functionptr);/*creates the object of list*/
	struct stat s;
	if( stat(argv[2],&s) == 0 )/*if the given file or directory's path is right*/
	{
	
		if( s.st_mode & S_IFDIR)/*if it is a directory*/
		{
			od=opendir(argv[2]);/*opens the directory*/
			int choice;
			FILE * write;
			write=fopen(argv[1],"r");/*opens the file to write to ready this tells if the file exist or not*/
			if(write!=NULL)/*chech weather the file given to write already exists*/
			{
				fclose(write);
				printf("The file exist: do you want  to overwrite it? Enter 1 for yes and 2 for no: ");
				scanf("%d",&choice);/*give the choice to overwrite or not*/
				if(choice ==1)/*if user wants to overwrite*/
				{
					traverse_dir(od,argv[2],sl);/*calls the traverse_dir to traverse the entire directory*/
					if(check==0)/*if the check static variable is 0 which means the either the directory is empty or file inside is empty*/
					{
						printf("directory or all files inside the directory is empty. Therefore,overwriting a file will change the content of the file but there will not be anything\n");
						printfile(sl,argv[1]);
						SLDelete(sl);/*free the list object*/
						closedir(od);/*closes the directory*/
						exit(0);
					}
					printfile(sl,argv[1]);/*calls the printfile which will take filename as parameter to print data into file*/
					deleteList(sl);/*free the list*/
					SLDelete(sl);/*free the list object*/
				}
				else/*if the user does not want to overwrite*/
				{
					closedir(od);
					printf("The file has not been overwrittern\n");
					exit(0);
				}
			}
			else/*if the file to write does not exist*/
			{
				traverse_dir(od,argv[2],sl);
				if(check==0)/*if the check static variable is 0 which means the either the directory is empty or file inside is empty*/
				{
					printf("directory or file inside the dir is empty.\n");
					SLDelete(sl);
					exit(0);
				}
				printfile(sl,argv[1]);
		   		closedir(od);
				deleteList(sl);
				SLDelete(sl);
			}
			return 0;
		}
		else if( s.st_mode & S_IFREG )/*if the reading file is a file*/
		{
			FILE * open;
			open=fopen(argv[2],"r");/*open the file to read*/
			int choice;
			FILE * write;
			write=fopen(argv[1],"r");/*open the file to write to see the file is exist or not*/
			if(write!=NULL)/*if the file exist*/
			{
				printf("The file exist: do you want  to overwrite it? Enter 1 for yes and 2 for no: ");
				scanf("%d",&choice);
				if(choice ==1)
				{
					storefile(open,argv[2],sl);
					if(check==0)/*check is 0 which means the file is empty*/
					{
						printf("File is empty. Therfore overwriting a file overwrites it but there will not be anything written\n");
						printfile(sl,argv[1]);
						SLDelete(sl);
						exit(0);
					}
					
					printfile(sl,argv[1]);
					fclose(open);
					deleteList(sl);
					SLDelete(sl);
				}
				else
				{
					printf("file has not been overwritten\n");
					fclose(open);
					exit(0);
				}
			}
			else/*if the file to write does not exist*/
			{
				storefile(open,argv[2],sl);
				if(check==0)
				{
					fclose(open);
					printf("File is empty. Therefore the file to overwrite will not be created \n");
					SLDelete(sl);
					exit(0);
				}
				storefile(open,argv[2],sl);
				printfile(sl,argv[1]);
				fclose(open);
				deleteList(sl);
				SLDelete(sl);
				
				
			}
		
		}
		return 0;
	}
	else/*if the path to read the files is not right*/
	{
		printf("error in opening directory or file. The path is not proper\n");
		return 0;
	}
   

}



	
