#ifndef SEARCH_H
#define SEARCH_H
#include "searchsorted-list.h"
#include <stdio.h>
//typedef int (*CompareFuncT)(void *, void *);
//typedef struct SortedList* SortedListPtr;
/* This method will search the fileneams when the user give queries with 
 * logical and
 * If there is one or more files that has all the queries,
 * it will print the filename*/
void searchandfile(SortedListPtr slist,int c);

/* This method will search the fileneams when the user give queries with 
 * logical or
 * it will print the filenames for each query because it is OR*/
void searchorfile(SortedListPtr orlist,int c);

/*this method creates the another linked list structure
 * but this linked list hase only the queries user provided
 * this store the queries and its file from the main linked list structure
 */
void separatelist(SortedListPtr sl,char * s);

/*this method store data from the file into my linked list structure*/
void storedata(FILE *fp,SortedListPtr slfile);

#endif
