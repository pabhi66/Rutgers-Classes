#ifndef SEARCHSORTED_LIST_H
#define SEARCHSORTED_LIST_H
typedef int (*CompareFuncT)(void *, void *);

/*this struct is used to create the node
*/
struct node
{
		char *file;
		char * freq;
		struct node * next;
};

typedef struct token *token_t;
/*this struct is used to create the list of node which has tokens in it
*/
struct token
{
	char * term;
	token_t  nexttoken;
	struct node *nextfile;
};


struct SortedList
{	 
	 struct node *headfile;
	 token_t headtoken;
	 CompareFuncT com;
	 
};
typedef struct SortedList* SortedListPtr;
/*this is used to create the iterator object*/
struct SortedListIterator
{
	token_t head;
};
typedef struct SortedListIterator* SortedListIteratorPtr;

/*This  method is used to create the list pointer
* This will return the SortedListPtr object
*/
SortedListPtr SLCreate(CompareFuncT cf);

/*This method is used to insert token into the list
it takes three parameters list, filename which is being read and the token
*/
int SLInserttoken(SortedListPtr list, char *newObj,char *filename,char * fr);


/*this is used to insert the filename and freq
this takes struct token object and filename
*/
int SLInsertfile(token_t rightlist, char *newObj,char * fr);


/*this will delete the list object*/
void SLDelete(SortedListPtr s);


void freememory(char * f);

/*This will deallocate the memory used by the entire list*/
int deleteList(SortedListPtr deletelist);


#endif
