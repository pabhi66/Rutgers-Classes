#ifndef QUEUE_H
#define QUEUE_H


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#define QUEUESIZE 5
/*struct for the queue*/
typedef struct {
	char *book[QUEUESIZE];
	double price[QUEUESIZE];
	double ouid[QUEUESIZE];
	char *category[QUEUESIZE];
	long head, tail;
	int full, empty;
	pthread_mutex_t *mut;
	pthread_cond_t *notFull, *notEmpty;
}queue;

queue *queueInit (void);//initialize the queue*/
void queueDelete (queue *q);/*destroys the lock and condition variable*/
void queueAdd (queue *q,char * to[4]);/*add data to the queue*/
void queueDel (queue *q, char *out,double *,double *,char *);/*delete the data from the queue*/



#endif
