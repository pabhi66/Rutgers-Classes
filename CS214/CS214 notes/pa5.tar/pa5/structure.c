#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structure.h"

/*initialize the user info list*/
DataListPtr SLCreate()
{
	DataListPtr sl = (struct DataList*)malloc(sizeof(struct DataList));/*create memory for the struct SortedList object*/
	sl->headlist=NULL;
    return sl;
}

/*initialize the success order list*/
SuccessListPtr SLSuccess()
{
	SuccessListPtr sls = (struct SuccessList*)malloc(sizeof(struct SuccessList));/*create memory for the struct SortedList object*/
	sls->headlist=NULL;
    return sls;
}
/*initialize the unsuccess order list*/
UnsuccessListPtr SLUnsuccess()
{
	UnsuccessListPtr uns = (struct UnsuccessList*)malloc(sizeof(struct UnsuccessList));/*create memory for the struct SortedList object*/
	uns->list=NULL;
    return uns;
}
/*initialize the last output list with name and id of user list*/
recordListPtr SLnode()
{
	recordListPtr n = (struct record*)malloc(sizeof(struct record));/*create memory for the struct SortedList object*/
	n->head=NULL;
    return n;
}
/*initialize the category list*/
catePtr SLCate()
{
	catePtr sl = (struct cateList*)malloc(sizeof(struct cateList));/*create memory for the struct SortedList object*/
	sl->head=NULL;
    return sl;
}

/*This method will be used to store the
 * categories into the list*/
int SLCateInsert(catePtr scat,char * name)
{
	struct cate *new;
	new=(struct cate*)malloc(sizeof(struct cate));
	new->ca=strdup(name);
	new->cnext=NULL;
	struct cate * cur11=scat->head;
	if(cur11==NULL)
	{
		
		scat->head=new;
		return 1;
	}
	else
	{
			while(cur11->cnext!=NULL)
			{
				cur11=cur11->cnext;
			}
			cur11->cnext=new;
			return 1;
	}
}
/*this method will be used to the insert the data into 
 * the data structure*/
int SLInsertuser(DataListPtr list, char *to[6])
{
  struct user * new;
  new = (struct user*)malloc(sizeof(struct user));/*allocate memory for new node*/
  new->name=to[0];
  new->uid=atoi(to[1]);
  new->fund=atof(to[2]);
  new->address=to[3];
  new->state=to[4];
  new->zip=to[5];
  new->next=NULL;
  if(list->headlist==NULL)/*if the list is empty*/ 
  {
	  list->headlist=new;/*insert the first node and give the headtoken pointer to that node*/
	  return 1;
  }
  else/*if the list is not empty*/
  {
	  struct user * cur=list->headlist;
	  while(cur->next!=NULL)/*traverse through the end of list*/
	  {
		  cur=cur->next;
	  }
	  cur->next=new;
  }
	return 0;
}


/*this method will store the user name and id 
 * to the output list from the user list*/
void insertrec(DataListPtr d,recordListPtr r)
{
	struct user * dd=d->headlist;
	
	while(dd!=NULL)
	{
		struct node *new=(struct node *)malloc(sizeof(struct node));
		new->name=strdup(dd->name);
		new->id=dd->uid;
		new->next=NULL;
		new->s=NULL;
		new->uns=NULL;
		if(r->head==NULL)
		{
			r->head=new;
		}
		else
		{
			struct node *cur=r->head;
			while(cur->next!=NULL)
			{
				cur=cur->next;
				
			}
			cur->next=new;
		}
		dd=dd->next;
		
	}
}
/*this method will be used to insert the
 * successful order to that user*/
void insertsuc(struct node *n,char *book,double price,double remain)
{
	struct success *new=(struct success *)malloc(sizeof(struct success));
	new->book=book;
	new->bookprice=price;
	new->remain=remain;
	new->next=NULL;

	struct success *s1=n->s;
	if(s1==NULL)
	{
		
		s1=new;
		n->s=s1;
	}
	else
	{
		while(s1->next!=NULL)
		{
			s1=s1->next;
		}
		s1->next=new;
	}
}

/*this method will be used to store
 * the unsuccessful order into the
 * list*/
void insertunsuc(struct node *n,char *book,double price)
{
	struct unsuccess *new=(struct unsuccess *)malloc(sizeof(struct unsuccess));
	new->book=book;
	new->price=price;
	new->onext=NULL;
	
	struct unsuccess *s1=n->uns;
	if(s1==NULL)
	{
		s1=new;
		n->uns=s1;
	}
	else
	{
		while(s1->onext!=NULL)
		{
			s1=s1->onext;
		}
		s1->onext=new;
	}
}
