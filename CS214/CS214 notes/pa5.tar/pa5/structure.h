#ifndef STRUCTURE_H
#define STRUCTURE_H
/*structure for the 
 * user data */
struct user
{
	char *name;
	char uid;
	double fund;
	char *address;
	char *state;
	char *zip;
	struct user * next;
};

struct DataList
{	 
	struct user *headlist;
	
};
typedef struct DataList* DataListPtr;

/*structure for categories*/
struct cate
{
	char * ca;
	struct cate * cnext;
};

struct cateList
{	 
	struct cate * head;
	
};
typedef struct cateList * catePtr;
/*structure for the last output
 * list with success and unsuccess list*/
struct node
{
	int id;
	char *name;
	struct node *next;
	struct success *s;
	struct unsuccess *uns;
};
typedef struct node * nodeListPtr;

struct record
{	 
	struct node *head;
	
};


typedef struct record * recordListPtr;
/*structure for the successful order*/
struct success
{
	char *book;
	double bookprice;
	double remain;
	struct success * next;
};
struct SuccessList
{	 
	struct success *headlist;
	
};


typedef struct SuccessList* SuccessListPtr;
/*structure for the unsuccess order*/
struct unsuccess
{
	char *book;
	double price;
	struct unsuccess * onext;
	
};
struct UnsuccessList
{	 
	struct unsuccess *list;
	
};
typedef struct UnsuccessList* UnsuccessListPtr;

/*initialize the user info list*/
DataListPtr SLCreate();

/*initialize the success order list*/
SuccessListPtr SLSuccess();

/*initialize the unsuccess order list*/
UnsuccessListPtr SLUnsuccess();

/*initialize the last output list with name and id of user list*/
recordListPtr SLnode();

/*initialize the category list*/
catePtr SLCate();

/*this method will store the user name and id 
 * to the output list from the user list*/
void insertrec(DataListPtr d,recordListPtr r);

/*This method insert the token into the list 
 * then it will call SLInsertfile method
 * which will store the file and freq for that token
 * newObj is the token, filename is file and fr is the freq
 */
int SLCateInsert(catePtr scat,char * name);

/*this method will be used to the insert the data into 
 * the data structure*/
int SLInsertuser(DataListPtr list, char *to[6]);

/*this method will be used to insert the
 * successful order to that user*/
void insertunsuc(struct node *n,char *book,double price);

/*this method will be used to store
 * the unsuccessful order into the
 * list*/
void insertsuc(struct node *n,char *book,double price,double remain);
#endif
