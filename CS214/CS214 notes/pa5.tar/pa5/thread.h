#ifndef THREAD_H
#define THREAD_H
#include <stdio.h>
#include <pthread.h>
#include "structure.h"
#include "queue.h"
DataListPtr sl;/*user data info list*/
pthread_mutex_t lock,lock2;
SuccessListPtr su;/*successful order list*/
UnsuccessListPtr uns;/*unsuccessful order list*/
recordListPtr reco;/*output list*/
catePtr sca;/*category list*/
char * path1;
int count;/*total categories */
double revenue;

/*this method will insert the user data and information
 * from the file and insert into the list using the method 
 * SLInsertuser*/
void storedata(char * p,FILE *fp,DataListPtr sl);

/*this method will open the file and reads the category and 
 * store into the list using  SLCateInsert*/
void storecate(char * p,catePtr sca);

/*This method will read the data from the user infomation
 * and call the method storedata to store into the list*/
void readfile(char * path,DataListPtr sl);

/*this method will substract the order price from the user's fund 
 * if the user has enough fund then it will call the insertsuc
 * method to store the orders into the successful list
 * and if the fund is not enough then it will call insertunsuc
 * to store the ordres into the unsuccessful list*/
void checkFund(double order_p,int id,char * book);

/*this method is for consumer thread
 * consumer threads will take the data from the queue and pass the
 * information to checkfund method and delete the data from the queue
 * if the queue is empty then it will wait for the producer
 * to fill the queue*/
void * consumer(void * q);

/*this method will be used by producer thread
 * it will fill the queue from reading the order file
 * once the queue is full it will wait for the
 * consumer thread to make queue nonfull
 */
void * producer(void * q);

/*this method will write to the output file
 * using success list and unsuccess list*/
void print(char * pa);

/*removes the list*/
void SLDelete(void * s);

/*deletes the user list*/
void Deletedata(DataListPtr s);

/*deletes the success list*/
void Deletesuc(SuccessListPtr s);

/*deletes the unsuccess list*/
void Deleteuns(UnsuccessListPtr s);

/*deletes the category list*/
void Deletecat(catePtr s);

/*deletes the output list with name and id of the user*/
void Deletenode(recordListPtr s);



#endif
