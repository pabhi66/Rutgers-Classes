#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include "thread.h"
#include <pthread.h>

pthread_t tid;
queue *q;/*queue*/

char * path;/*path is the path for the order file*/

int main(int argc, char ** argv)
{
	revenue=0;
	if(argc!=5)
	{
		exit(0);
		
	}
	sca=SLCate();/*this will create the list for category*/
	sl=SLCreate();//creates the object of list of user data*/
	q=queueInit();/*initialize the queue*/
	readfile(argv[1],sl);/*this method will store the user information into list*/
	storecate(argv[3],sca);/*this will store the category into list*/
	reco=SLnode();/*this will initialize the list for final output with success and unsuccess order list*/
	insertrec(sl,reco);/*this will store the user name and id for the output*/
	path1=argv[2];/*path of the order file*/
	su=SLSuccess();/*initialize the success order list*/
	uns=SLUnsuccess();/*initialize the unsuccess order list*/
	
	if(pthread_mutex_init(&lock,NULL)!=0)
	{
		printf("Mutex init failed\n");
	}
	if(pthread_mutex_init(&lock2,NULL)!=0)
	{
		printf("Mutex init failed\n");
	}
	pthread_create(&tid,NULL,&producer,q);/*creates the producer thread*/
	pthread_t tcons[count];/*count the number of categories. Count is in the method of storecate*/
	int i=0;
	for(i=0;i<count;i++)
	{
		pthread_create(&tcons[i],NULL,&consumer,q);/*creates the consumer thread*/
		
	}
	pthread_join(tid,NULL);
	for(i=0;i<count;i++)
	{
		pthread_join(tcons[i],NULL);
	}
	
	pthread_mutex_destroy(&lock);
	printf("Totak revenue gained %.2lf\n\n",revenue);
	queueDelete(q);/*destroy the lock for queue*/
	print(argv[4]);/*methods writes output into the file*/
	Deletedata(sl);/*delete the user data list*/
	Deletesuc(su);/*delete the success order list*/
	Deleteuns(uns);/*delete the unsuccess order list*/
	Deletecat(sca);/*delete the category list*/
	Deletenode(reco);/*delete the last output list*/
	SLDelete(sl);
	SLDelete(sca);
	SLDelete(uns);
	SLDelete(reco);
	
	return 0;
}
