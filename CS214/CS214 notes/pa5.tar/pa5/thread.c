#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "thread.h"
int g=0;
int cd=0;
//double revenue=0;
/*this method will insert the user data and information
 * from the file and insert into the list using the method 
 * SLInsertuser*/
void storedata(char * p,FILE *fp,DataListPtr sl)
{
	char * line = NULL;
	size_t len = 0;
	ssize_t read;
	int empty=0;
	char *to[6];/*array of information of user*/
	while ((read = getline(&line, &len, fp)) != -1) /*reads the line from the file*/
	{
		empty++;
		int i=0;
		to[0]=strtok(line,"|\"\n");/*gets the token*/
		while(to[i]!=NULL)
		{
			i++;
			to[i]=strtok(NULL,"|\"\n");
		}
		SLInsertuser(sl,to);/* insert into list using this method*/
	}
	if(empty==0)/*if there is nothing in the file*/
	{
		printf("%s is empty file\n",p);
		exit(0);
	} 
	
}
/*this method will open the file and reads the category and 
 * store into the list using  SLCateInsert*/
void storecate(char * p,catePtr sca)
{
	count=0;
	struct stat s;
	if( stat(p,&s) == 0 )/*if the given file or directory's path is right*/
	{
		if( s.st_mode & S_IFDIR)/*if it is a directory*/
		{
			printf("No directory should be given in the argument\n");
			exit(0);
				
		}	
			else if( s.st_mode & S_IFREG )/*if the reading file is a file*/
			{
				FILE * open;
				open=fopen(p,"r");/*open the file to read*/
				if(open!=NULL)/*if the file exist*/
				{
					char * line = NULL;
					size_t len = 0;
					ssize_t read;
					int empty=0;
					char * to;
					while ((read = getline(&line, &len, open)) != -1) /*reads the line from the file*/
					{
						empty++;
						count++;/*this is used to create the consumer thread acording to categories*/
						to=strtok(line,"\n");
						SLCateInsert(sca,to);
					}
				
					if(empty==0)/*if there is nothing in the file*/
					{
						printf("%s is empty file\n",p);
						exit(0);
					}
				}	
				
		}
		}
		else/*if the path to read the files is not right*/
		{
			printf("error in opening directory or file. The path is not proper\n");
			exit(0);
		}
}

/*This method will read the data from the user infomation
 * and call the method storedata to store into the list*/
void readfile(char * path,DataListPtr sl)
{
	struct stat s;
	if( stat(path,&s) == 0 )/*if the given file or directory's path is right*/
	{
		
		if( s.st_mode & S_IFDIR)/*if it is a directory*/
		{
			printf("No directory should be given in the argument\n");
			exit(0);
				
		}	
			else if( s.st_mode & S_IFREG )/*if the reading file is a file*/
			{
				FILE * open;
				open=fopen(path,"r");/*open the file to read*/
				if(open!=NULL)/*if the file exist*/
				{
					
					storedata(path,open,sl);/*calls the storedata to store the data into the data structure*/
				
				
				}
			}
		}
		else
		{
			printf("error in opening directory or file. The path is not proper\n");
			exit(0);
		}
}
/*this method will substract the order price from the user's fund 
 * if the user has enough fund then it will call the insertsuc
 * method to store the orders into the successful list
 * and if the fund is not enough then it will call insertunsuc
 * to store the ordres into the unsuccessful list*/
void checkFund(double order_p,int id,char * book)
{
	
	struct user * cur1=sl->headlist;/*pointer to the user data list*/
	struct node * cur=reco->head;/*pointer to the last output list */
	while(cur!=NULL)
	{
		if(id==cur->id)
		{
			if((cur1->fund-order_p)>0)/*check whether user has enough fund*/
			{
				cur1->fund=cur1->fund-order_p;
				double remain=cur1->fund;
				revenue+=order_p;
				printf("Succeeded\n");
				printf("Customer name is :%s\n",cur1->name);
				printf("Customer id is: %d\n",cur1->uid);
				printf("Customer Information is : %s\n",cur1->address);
				printf( "State : %s\n",cur1->state);
				printf("zip : %s\n",cur1->zip);
				printf("book name is : %s\n",book);
				printf("book price is %.2lf\n",order_p);
				printf("Customer's fund is %.2lf\n\n",remain);
				insertsuc(cur,book,order_p,remain);/*method to store the order into successful order list*/
				
				
			}
			else
			{
				printf("rejected\n");
				printf("Customer name is :%s\n",cur1->name);
				printf("Customer id is: %d\n",cur1->uid);
				printf("book name is : %s\n",book);
				printf("book price is %.2lf\n",order_p);
				printf("Customer's fund is %.2lf\n\n",cur1->fund);
				
				insertunsuc(cur,book,order_p);/*method to store the order into unsuccessful order list*/
			}
		}
		cur1=cur1->next;
		cur=cur->next;
		
	}
	
}


/*this method is for consumer thread
 * consumer threads will take the data from the queue and pass the
 * information to checkfund method and delete the data from the queue
 * if the queue is empty then it will wait for the producer
 * to fill the queue*/
void * consumer(void * q)
{
	pthread_mutex_lock(&lock);
	queue *fifo;
	fifo = (queue *)q;
	while(cd<=g)/*g is the total number of orders that are stored into the queue*/
	            /*cd is the counter for  the consumer thread which count how many data 
	            * consumer thread has done*/           
	{
		
		pthread_mutex_lock (fifo->mut);
		while (fifo->empty) 
		{
			if(cd<g || cd==0)
			{

				pthread_cond_wait (fifo->notEmpty, fifo->mut);
			}
			else
			{
				break;
			}	
		}
		if(cd==g )/*if the consumer thread has done with all orders*/
		{
			
			pthread_mutex_unlock (fifo->mut);
			pthread_mutex_unlock(&lock);
			pthread_cond_signal (fifo->notFull);
		
			break;
		}
	
		cd++;
		char * b=fifo->book[fifo->head];
		double temp=fifo->price[fifo->head];
		double temp1=fifo->ouid[fifo->head];
		char * c=fifo->category[fifo->head];
		checkFund(temp,temp1,b);/*calls the checkfund method for the succesful or unsuccessful order*/
		queueDel(fifo,b,&temp,&temp1,c);/*call this method to delete the data*/
		pthread_mutex_unlock(&lock);
		pthread_mutex_unlock (fifo->mut);	
		pthread_cond_signal (fifo->notFull);
		usleep (10000);	
	}
	return NULL;
}
/*this method will be used by producer thread
 * it will fill the queue from reading the order file
 * once the queue is full it will wait for the
 * consumer thread to make queue nonfull
 */
void * producer(void * q)
{
	queue *fifo;

	fifo = (queue *)q;
	struct stat s;
	if( stat(path1,&s) == 0 )/*if the given file or directory's path is right*/
	{
		
		if( s.st_mode & S_IFDIR)/*if it is a directory*/
		{
			printf("No directory should be given in the argument\n");
			exit(0);
				
		}	
		else if( s.st_mode & S_IFREG )/*if the reading file is a file*/
		{
			FILE * open;
			open=fopen(path1,"r");/*open the file to read*/
			if(open!=NULL)/*if the file exist*/
			{
				char * line = NULL;
				size_t len = 0;
				ssize_t read;
				int empty=0;
				char *to[4];//ahya array ma pro ave che 6 to size che
				while ((read = getline(&line, &len,open )) != -1) /*reads the line from the file*/
				{
					pthread_mutex_lock (fifo->mut);
					if(strcmp(line,"\r\n")!=0)/*if there is no empty line into the file*/
					{
						while (fifo->full) 
						{
						
							pthread_cond_wait (fifo->notFull, fifo->mut);
						}
						
						empty++;
						int i=0;
						to[0]=strdup(strtok(line,"|\"\n"));/*get the tokens from the order file*/
						while(to[i]!=NULL)
						{
							i++;
							to[i]=strtok(NULL,"|\"\n ");
						}
						int check=0;
						struct cate * cat=sca->head;
						while(cat!=NULL)/*check if the order category is in the category file*/
						{
							if(strcmp(to[3],cat->ca)==0)
							{
								check=1;
								break;
							}
							else
							{
								cat=cat->cnext;
							}
						}	
						if(check==1)
						{
							g++;
							queueAdd(fifo,to);/*add into the ququ*/
							
						}
					}
					pthread_cond_signal (fifo->notEmpty);
					pthread_mutex_unlock (fifo->mut);
					
				}
				if(empty==0)/*if there is nothing in the file*/
				{
					printf("%s is empty file\n",path1);
					exit(0);
				}
			}
		}
	}
	else/*if the path to read the files is not right*/
	{
		printf("error in opening directory or file. The path is not proper\n");
		exit(0);
	}
	return NULL;
}
/*this method will write to the output file
 * using success list and unsuccess list*/
void print(char * pa)
{
	struct stat s1;
	stat(pa,&s1);//if the given file or directory's path is right

	FILE * open;
	open=fopen(pa,"w");//open the file to reade
	if(open!=NULL)
	{
		struct node *r=reco->head;/*list of the name and id of the user*/
		struct user* cur=sl->headlist;/*pointer to the user data list*/
		double d;
		while(r!=NULL)
		{
				struct success *s=r->s;
				fprintf(open,"############# START OF CUSTOMER INFO ##############\n");
				fprintf(open,"Customer Name: %s \n",  r->name);
				fprintf(open,"Customer id: %d \n",r->id);
				fprintf(open,"##################SUCCESSFUL################\n");
				int c=0;
				while(s!=NULL)//ahya j nathi jatu
				{
					c=1;
					fprintf(open,"%s | ",s->book);
					fprintf(open,"%.2lf | ",s->bookprice);
					fprintf(open,"%.2lf ",s->remain);
					fprintf(open,"\n");
					d=s->remain;
					s=s->next;
					
				}
				fprintf(open,"\n");
				fprintf(open,"###################UNSUCCESSFUL###############\n");
				struct unsuccess *un=r->uns;
				
				while(un!=NULL)
				{
					c=1;
					fprintf(open,"%s | ",un->book);
					fprintf(open,"%.2lf  ",un->price);
					fprintf(open,"\n");
					un=un->onext;
				}
				fprintf(open,"------------------DONE WITH ALL ORDERS FOR THIS CUSTOMER-----------------");
				
				if(c==1)
				{
					fprintf(open,"\nRemaining credit balance after all purchases (a dollar amount): %.2lf \n",d);
				}
				else
				{
					fprintf(open,"\nRemaining credit balance after all purchases (a dollar amount): %.2lf \n",cur->fund);
				}
				fprintf(open,"\n############### END OF CUSTOMER INFO ######################");
				fprintf(open,"\n\n\n");
				
				r=r->next;
				cur=cur->next;
		}
			fprintf(open,"Total revenue gained : $%.2lf",revenue);
			fclose(open);
	}
		
	
	
	else//if the path to read the files is not right
	{
		printf("error in opening directory or file. The path is not proper\n");
		exit(0);
	}
}

/*removes the list*/
void SLDelete(void * s)
{
	free(s);
	s=NULL;
}

/*deletes the user list*/
void Deletedata(DataListPtr s)
{
	struct user *temp=NULL;
	while(s->headlist) 
	{
		temp=s->headlist->next;
		free(s->headlist);
		s->headlist=temp;
	}
}

/*deletes the success list*/
void Deletesuc(SuccessListPtr s)
{
	struct success *temp=NULL;
	while(s->headlist) 
	{
		temp=s->headlist->next;
		free(s->headlist);
		s->headlist=temp;
	}
}

/*deletes the unsuccess list*/
void Deleteuns(UnsuccessListPtr s)
{
	struct unsuccess *temp=NULL;
	while(s->list) 
	{
		temp=s->list->onext;
		free(s->list);
		s->list=temp;
	}
}

/*deletes the category list*/
void Deletecat(catePtr s)
{
	struct cate *temp=NULL;
	while(s->head) 
	{
		temp=s->head->cnext;
		free(s->head);
		s->head=temp;
	}
}
/*deletes the output list with name and id of the user*/
void Deletenode(recordListPtr s)
{
	struct node *temp=NULL;
	while(s->head) 
	{
		s->head->s=NULL;
		s->head->uns=NULL;
		temp=s->head->next;
		
		free(s->head);
		s->head=temp;
	}
}
