#include "queue.h"
/*initialize the queue*/
queue *queueInit (void)
{
	queue *q;

	q = (queue *)malloc (sizeof (queue));
	if (q == NULL) return (NULL);

	q->empty = 1;
	q->full = 0;
	q->head = 0;
	q->tail = 0;
	q->mut = (pthread_mutex_t *) malloc (sizeof (pthread_mutex_t));
	pthread_mutex_init (q->mut, NULL);
	q->notFull = (pthread_cond_t *) malloc (sizeof (pthread_cond_t));
	pthread_cond_init (q->notFull, NULL);
	q->notEmpty = (pthread_cond_t *) malloc (sizeof (pthread_cond_t));
	pthread_cond_init (q->notEmpty, NULL);
	
	return (q);
}
/*destroys the losk for the queue*/
void queueDelete (queue *q)
{
	pthread_mutex_destroy (q->mut);
	free (q->mut);	
	pthread_cond_destroy (q->notFull);
	free (q->notFull);
	pthread_cond_destroy (q->notEmpty);
	free (q->notEmpty);
	free (q);
}
/*this method will add the data into the queue*/
void queueAdd (queue *q, char *to[4])
{
	q->book[q->tail]= to[0];
	q->price[q->tail]=atof(to[1]);
	q->ouid[q->tail]=atof(to[2]);
	q->category[q->tail]=to[3];
	q->tail++;
	if (q->tail == QUEUESIZE)
		q->tail = 0;
		
	if (q->tail == q->head)
		q->full = 1;
	q->empty = 0;

	return;
}
/*this method delete the data from the queue*/
void queueDel (queue *q, char *out,double * p,double * i,char* c )
{
	//*out = q->buf[q->head];
	
	out=q->book[q->head];
	*p=q->price[q->head];
	*i=q->ouid[q->head];
	c=q->category[q->head];
	
	q->head++;
	if (q->head == QUEUESIZE)
		q->head = 0;
	if (q->head == q->tail)
		q->empty = 1;
	q->full = 0;
}

