#ifndef MALLOC_H
#define MALLOC_H
#include <stdio.h>
#include <string.h>
#include <unistd.h>
struct MemEntry
{
	char ptr[4];
	struct MemEntry *prev;
	struct MemEntry *succ;
	int isfree; // 1-yes 0-no
	int size;
};

#define malloc( x ) my_malloc( x,__FILE__ , __LINE__ )
#define free( x ) my_free( x, __FILE__ , __LINE__ )
/* return a pointer of the memory requested  and if the memory is not enough then return an error*/
void* my_malloc(unsigned int size,char * file, int line);

/*my_free function frees the pointer if it is a valid pointer
 * otherwise print an error message according to error message*/
void my_free(void *p,char * file,int line);
#endif
