#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "malloc.h"

int main()
{
	int choice;
	printf("1. Trying to allocate more memory than the array size and then free it\n");
	printf("2. free pointer which is not created using malloc\n");
	printf("3. doing free(ptr+500) \n");
	printf("4. Mallocated pointer pointing to an int and trying to free it\n");
	printf("5. creating memory with size 0 and try to free it\n");
	printf("6. Doing free(ptr+10) where ptr is allocated using 5001 bytes which is more memory than array size and free the pointer itself\n");
	printf("7. trying to free same pointer two times\n");
	printf("8. allocating pointer and freeing it and again allocating pointer and freeing it.. NO ERROR\n");
	printf("Enter your choice for testcases: ");
	scanf("%d",&choice);
	getchar();
	while(choice>=1 && choice<=8)
	{
		if(choice==1)/*Trying to allocate more memory than the array size and then free it*/
		{
			int * ptr=(int *)malloc(sizeof(int)*850);
			free(ptr);
		}
		else if(choice==2)/*free pointer which is not created using malloc*/
		{
			int x=10;
			free(&x);
		}
		else if(choice==3)/*doing free(ptr+500)*/
		{
			char *ptr2=(char *)malloc(280);
			free(ptr2+500);
			free(ptr2);
		}
		else if(choice==4)/*Mallocated pointer pointing to an int and trying to free it*/
		{
			int *p = (int*) malloc(sizeof(int));
			int a = 42;
			p = &a;
			free(p);
		}
		else if(choice==5)/*creating memory with size 0 and try to free it*/
		{
			char * ptr=(char *)malloc(0);
			free(ptr);
		}
		else if(choice==6)/*Doing free(ptr+10) where ptr is allocated using 5001 bytes which is more memory than array size*/
		{
			char * ptr=(char *)malloc(5001);
			free(ptr+10);
			free(ptr);
		}
		
		else if(choice==7)/*trying to free same pointer two times*/
		{
			char * ptr2=(char *)malloc(280);
			free(ptr2);
			free(ptr2);
			
		}
		else if(choice==8)/*allocating pointer and freeing it and again allocating pointer and freeing it.. NO ERROR*/
		{
			char * ptr=(char *)malloc(200);
			free(ptr);
			ptr=(char *)malloc(200);
			free(ptr);
		}
		printf("Enter your choice for testcases: ");
		scanf("%d",&choice);
	}
	return 0;
}
