#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "malloc.h"

#define BLOCKSIZE	5000
static char big_block[BLOCKSIZE];


static struct MemEntry *root=(struct MemEntry*)big_block;/*pointing to the start of array which is larger block*/
static struct MemEntry *rootsmall;/*needed for fragmentation points to last 2000 bytes in the array*/

/* return a pointer of the memory requested  and if the memory is not enough then return an error*/
void* my_malloc(unsigned int size,char * file, int line)
{
	static int 		initialized = 0;
	struct MemEntry *p;
	struct MemEntry *psmall;
	struct MemEntry *succ;
	if(size>0)
	{
		if(!initialized)	// 1st time called
		{
			// create a root chunk at the beginning of the memory block
			rootsmall=(struct MemEntry*)((char *)root +3000);
			root->prev = root->succ = 0;
			rootsmall->prev=root->succ=0;
			root->size = BLOCKSIZE - sizeof(struct MemEntry)-2000;
			rootsmall->size=BLOCKSIZE-sizeof(struct MemEntry)-3000;
			root->isfree = 1;
			rootsmall->isfree=1;
			rootsmall->ptr[0]='a';/*used to check whether the pointer for free is valid*/
			rootsmall->ptr[1]='b';
			rootsmall->ptr[2]='c';
			rootsmall->ptr[3]='d';
			root->ptr[0]='a';
			root->ptr[1]='b';
			root->ptr[2]='c';
			root->ptr[3]='d';
			initialized = 1;
		}
		p = root;/*points to the larger block*/
		psmall=rootsmall;/*points to the smaller block of array*/
	
		if(size>=100)/*size to check. If the size is >=100 then allocate from the larger block*/
		{
			do
			{
			
				if(p->size < size)
				{
					/*the current chunk is smaller, go to the next chunk*/
					p = p->succ;
				}
				else if(!p->isfree)
				{
					/*this chunk was taken, go to the next*/
					p = p->succ;
				}
				else if(p->size < (size + sizeof(struct MemEntry)))
				{
					// this chunk is free and large enough to hold data, 
					// but there's not enough memory to hold the HEADER of the next chunk
					// don't create any more chunks after this one
					p->isfree = 0;
					
					return (char*)p + sizeof(struct MemEntry);
				}
				else
				{
					/*take the needed memory and create the header of the next chunk*/
					succ = (struct MemEntry*)((char*)p + sizeof(struct MemEntry) + size);
					succ->prev = p;
					succ->isfree=1;
					succ->ptr[0]='a';
					succ->ptr[1]='b';
					succ->ptr[2]='c';
					succ->ptr[3]='d';
					succ->succ = p->succ;
					if(p->succ != 0)
					{
						p->succ->prev = succ;
					}
					p->succ = succ;
					succ->size = p->size - sizeof(struct MemEntry) - size;
					p->size = size;
					p->isfree = 0;
					return (char*)p + sizeof(struct MemEntry);
				}
			
			} while(p != 0);
			printf("ERROR : %s : %d: Could not allocate any more chunks from the bigger block.\n",file,line);
		}
		else/*allocate memory from smaller block*/
		{
			do
			{
				
			if(psmall->size < size)
			{
				/*the current chunk is smaller, go to the next chunk*/
				psmall = psmall->succ;
			}
			else if(psmall->isfree==0)
			{
				/*this chunk was taken, go to the next*/
				psmall = psmall->succ;
			}
			else if(psmall->size < (size + sizeof(struct MemEntry)))
			{
				// this chunk is free and large enough to hold data, 
				// but there's not enough memory to hold the HEADER of the next chunk
				// don't create any more chunks after this one
				psmall->isfree = 0;
				return (char*)psmall + sizeof(struct MemEntry);
			}
			else
			{
				/*take the needed memory and create the header of the next chunk*/
				succ = (struct MemEntry*)((char*)psmall + sizeof(struct MemEntry) + size);
				succ->prev = psmall;
				succ->isfree=1;
				succ->ptr[0]='a';
				succ->ptr[1]='b';
				succ->ptr[2]='c';
				succ->ptr[3]='d';
				succ->succ = psmall->succ;
				if(psmall->succ != 0)
				{
					psmall->succ->prev = succ;
				}
				psmall->succ = succ;
				succ->size = psmall->size - sizeof(struct MemEntry) - size;
				psmall->size = size;
				psmall->isfree = 0;
				return (char*)psmall + sizeof(struct MemEntry);
			}
			}while(psmall!=0);
			printf("ERROR : %s : %d: not malloc  from the smaller blacks.\n",file,line);
		}
	}
	else
	{
		printf("ERROR : %s : %d : the size should be greater than 0. \n",file,line);
	}
	return 0;
}
/*my_free function frees the pointer if it is a valid pointer
 * otherwise print an error message according to error message*/
void my_free(void *p,char * file,int line)
{
	struct MemEntry *ptr;
	struct MemEntry *prev;
	struct MemEntry *succ;
	if(p!=0)//checks whether the pointer is allocated
	{
		if(p>(void *)root && p<((void *)root+BLOCKSIZE))/*if the pointer is in the valid range*/
		{
			ptr = (struct MemEntry*)((char*)p - sizeof(struct MemEntry));
			if(ptr->ptr[0]=='a' && ptr->ptr[1]=='b' && ptr->ptr[2]=='c' && ptr->ptr[3]=='d')/*check whether the pointer hase struct MemEntry */
			{
				if(ptr->isfree==0)/*check if the block is not free*/
				{
					if((prev = ptr->prev) != 0 && prev->isfree==1)
					{
						// the previous chunk is free, so
						// merge this chunk with the previous chunk
						prev->size += sizeof(struct MemEntry) + ptr->size;
						ptr->isfree=1;
						prev->succ = ptr->succ;
						if(ptr->succ != 0)
						{
							ptr->succ->prev = prev;
						}
					}
					else
					{
						ptr->isfree = 1;
						prev = ptr;	// used for the step below
					}
	
					if((succ = ptr->succ) != 0 && succ->isfree)
					{
						// the next chunk is free, merge with it
					
						prev->size += sizeof(struct MemEntry) + succ->size;
						prev->isfree = 1;
						prev->succ = succ->succ;
						if(succ->succ != 0)
						{
							succ->succ->prev=prev;
						}
					}
				}
				else/*if the block is already free*/
				{
					printf("ERROR : %s : %d : freeing same pointer. \n",file,line);
				}
			}
			else
			{
				printf("ERROR : %s: %d : free()ing pointers to dynamic memory that were not returned from malloc().\n",file,line);
			}
		}
		else
		{
			printf("ERROR : %s : %d : free()ing pointers that were never allocated OR IF you have created ptr using successful malloc but you have passed the ptr with the size which made the freeing ptr to go out of bound of the heap memory range(array)\n",file,line);
		}

	}
	else
	{
		printf("ERROR : %s : %d : freeing memory which was not created either due to the 0 or <0 size allocation or insufficient memory.\n",file,line);
	}
}
