
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
static int co;/*it is the index to traverse through second string*/

struct TokenizerT_
{
	char *p1; /*struct member as character pointer to delimiter string*/
	char *p2; /*struct member as character pointer to token string*/
	
};
typedef struct TokenizerT_ TokenizerT;
 /*
  this method will create the struct object
  save two string in the struct object
  return the struct object containing two strings
  */
TokenizerT *TKCreate(char *separators, char *ts) {

  TokenizerT *tt1 = (TokenizerT*) malloc(sizeof(TokenizerT));/*dynamically allocate memory for the struct object pointer*/
  char * deli=separators;/*save the delimiter string in the character pointer*/
  char *str=ts;/*save the token string in the character pointer*/
  
  tt1->p1=deli;/*save the delimiter string into the first member pointer of struct*/
  tt1->p2=str;/*save the token string into the first member pointer of struct*/
  if(tt1!=NULL) /*if the object is not null then return object*/
  {
  	return tt1; 	
  }
  else          /*else return null*/
  {
  	return NULL;
  } 
}
/*
 *this method destroy the struct object
 */
void TKDestroy(TokenizerT *tk) {

	free(tk);//free the struct object
	tk=NULL;
}

/*
 *this method takes two character array of two string
 *it will return the index number of the character which is not as delimiter in the first string from the second string
 */
int  hastokens(char * del,char *exm){
	                                            
	int g=1;                                
	int k=0;
	int w=0;
	while(g==1)/*this loop continues until if find a index number to return or the index number reaches end of string*/
	{
		w=0;
		k=0;
	
		while(k<strlen(del) && w!=2) /*this loop continues until if find the character which is not in delimiter*/
		{
			if(del[k]==exm[co])/*this will check the character of second string to the character of first string*/
			{	
				w=2;/*if character in second string is delimiter it will make w=2*/
			}
			k++;
			
		}
		if(w==2)
		{
			if(co==(strlen(exm)))/*when the delimiter is found in token string and it is the end of string*/
			                     /*then this condition make the outer loop to finish*/
			{
				g=-1;
			}
			else             /*otherwise the outer lopp continues and increase the index number of token string*/
			{
				co++;
				g=1;
			}
		}
		else if(w!=2 && g==1)/*if the character in token string is not delimiter it will return token string's index number*/
		{
				return co;
		}
	}
	if(g==-1)/* when we do not find any character that in delimiter and the token string is finished then it will return the last index number of the second string*/
	{
		return co;
	}
	return 0;
}
/*
 *this method returns the index number of character when it finds the next delimiter in token string
 */
int nexttokens(char *a,char *b){	
	
	int g=1;                                 
	int k=0;
	int w=0;
	while(g==1)/*this will end when token strinf reaches at end or it will find the character which is in delimiter string*/
	{
		w=0;
		k=0;
		while(k<strlen(a) && w!=2)/*this loop will check whether the character in token string is in delimiter string*/
		{
			
			if(a[k]==b[co])/*if token string character is in delimiter string it will make w=2*/
			{	
				w=2;
			}
			k++;
		}
		if(w!=2)/*if the charachter in token string is not delimiter*/
		{
			if(co==strlen(b))/*and token string reaches at end*/
			{	
				g=-1;	/*this will make outer loop to finish*/
			}
			else     /*otherwise the outer loop continues*/
			{
				co++;/*increment my index number */
				g=1;
			}
		}
		else if(w==2)/*if we find the delimiter in token string it will return the index number of that character*/ 
		{
			return co;
		}		
	}
	if(g==-1)/*when the token string reaches at end it will return the last index number of string*/
	{
		return co;
	}
	return 0;
}

char * token;/*pointer to the tokenized string*/
char *TKGetNextToken(TokenizerT *tk) {
		
	char* string1 = tk->p1;/*takes the delimiter string from struct object and save into character pointer*/
	char* seperator = tk->p2;/*takes the token string from struct object and save into character pointer*/
	
	int a=hastokens(string1,seperator);/*calls a method hastokens*/
	int b=nexttokens(string1,seperator);/*calss a method nexttokens*/
	if(a>=0 && (b-a)>=0)/*if there is more than zero characters as token*/
	{
		token=((char *)malloc(((b-a)+1)*sizeof(char)));/*creates memory for tokenized string*/
		int count;
		int g=0;
		for(count=a;count<b;count++)/*loop through the index number returned through hastokens and next token method*/
		{			
			token[g]=seperator[count];/*save into token pointer*/
			g++;
		}
		token[g]='\0';/*add null byte to tokenized string*/
		return token;/*return tokenized string*/
	}
	else/*if there is no token then return '\0'*/
	{
		return '\0';
	}
}

int main(int argc,char **argv) {

	
	if(argc==3)
	{
		int i=0;
		int length1=(int)strlen(argv[1]);
		int length2=(int)strlen(argv[2]);
		int idxToDel=0;/*is used to for memmove function below.*/
		char * delim=(char*)malloc(sizeof(char)*length1);//create memory
		char * str=(char*)malloc(sizeof(char)*length2);
		for(i=0;i<(int)strlen(argv[1]);i++)
		{
			delim[i]=argv[1][i];
		}
		for(i=0;i<(int)strlen(argv[2]);i++)
		{
			str[i]=argv[2][i];
		}
		for(i=0;i<(int)strlen(delim);i++)/*this loop is for special character for delimiter string*/
		{
			if(delim[i]=='\\')/*if there is backslash*/
			{
				if(delim[i+1]=='n')/*if there is n after backslash*/ 
				{
					idxToDel = i;
					memmove( &delim[ idxToDel ] , &delim[ idxToDel+1 ], strlen(delim ) - idxToDel ) ;/*this function will move memory from two character to one charcter because \ and n are two character*/
					delim[i]=0x0a;/*this will store hex number of \n*/
				}
				else if(delim[i+1]=='t')/*if there is t after backslash */
				{	
					idxToDel = i;
					memmove( &delim[ idxToDel ] , &delim[ idxToDel+1 ], strlen(delim ) - idxToDel ) ;/*this function will move memory from two character to one charcter because \ and t are two character*/
					delim[i]=0x09;/*this will store hex number of \t*/
				}
				else if(delim[i+1]=='r')/*if there is r after backslash*/
				{
					idxToDel = i;
					memmove( &delim[ idxToDel ] , &delim[ idxToDel+1 ], strlen(delim ) - idxToDel ) ;/*this function will move memory from two character to one charcter because \ and r are two character*/
					delim[i]=0x0d;/*this will store hex number of \r*/
				}
				else if(delim[i+1]=='b')/*if there is b after backslash*/
				{
					idxToDel = i;
					memmove( &delim[ idxToDel ] , &delim[ idxToDel+1 ], strlen(delim ) - idxToDel ) ;/*this function will move memory from two character to one charcter because \ and b are two character*/
					delim[i]=0x08;/*this will store hex number of \b*/
				}
				else if(delim[i+1]=='f')/*if there is f after backslash*/
				{	
					idxToDel = i;
					memmove( &delim[ idxToDel ] , &delim[ idxToDel+1 ], strlen(delim ) - idxToDel ) ;/*this function will move memory from two character to one charcter because \ and f are two character*/
					delim[i]=0x0c;/*this will store hex number of \f*/
				}
				else if(delim[i+1]=='a')/*if there is a after backslash*/
				{
					idxToDel = i;
					memmove( &delim[ idxToDel ] , &delim[ idxToDel+1 ], strlen(delim ) - idxToDel ) ;/*this function will move memory from two character to one charcter because \ and a are two character*/
					delim[i]=0x07;/*this will store hex number of \a*/
				}
				else if(delim[i+1]=='v')/*if there is v after backslash*/
				{
					idxToDel = i;
					memmove( &delim[ idxToDel ] , &delim[ idxToDel+1 ], strlen(delim ) - idxToDel ) ;/*this function will move memory from two character to one charcter because \ and v are two character*/
					delim[i]=0x0b;/*this will store hex number of \*/				}
				else if(delim[i+1]!='\0')/*if there is anyother character than special character after backslash*/
				{
					idxToDel = i;
					delim[i]=delim[i+1];/*this will store the character after \ inplace of backslash*/
					memmove( &delim[ idxToDel ] , &delim[ idxToDel+1 ], strlen(delim ) - idxToDel ) ;/*this function will move memory from two character to one charcter because \ and any other character are two character*/
				}
			}	
		}
		for(i=0;i<(int)strlen(str);i++)/*this loop is same above but this is for token string*/
		{
			if(str[i]=='\\')
			{
				if(str[i+1]=='n')
				{
					idxToDel = i;
					memmove( &str[ idxToDel ] , &str[ idxToDel+1 ], strlen(str ) - idxToDel ) ;
					str[i]=0x0a;
				}
				else if(str[i+1]=='t')
				{
					idxToDel = i;
					memmove( &str[ idxToDel ] , &str[ idxToDel+1 ], strlen(str ) - idxToDel ) ;
					str[i]=0x09;
				}
				else if(str[i+1]=='r')
				{
					idxToDel = i;
					memmove( &str[ idxToDel ] , &str[ idxToDel+1 ], strlen(str ) - idxToDel ) ;
					str[i]=0x0d;
				}
				else if(str[i+1]=='b')
				{
					idxToDel = i;
					memmove( &str[ idxToDel ] , &str[ idxToDel+1 ], strlen(str ) - idxToDel ) ;
					str[i]=0x08;
				}
				else if(str[i+1]=='f')
				{
					idxToDel = i;
					memmove( &str[ idxToDel ] , &str[ idxToDel+1 ], strlen(str ) - idxToDel ) ;
					str[i]=0x0c;
				}
				else if(str[i+1]=='a')
				{	
					idxToDel = i;
					memmove( &str[ idxToDel ] , &str[ idxToDel+1 ], strlen(str) - idxToDel ) ;
					str[i]=0x07;
				}
				else if(str[i+1]=='v')
				{
					idxToDel = i;
					memmove( &str[ idxToDel ] , &str[ idxToDel+1 ], strlen(str ) - idxToDel ) ;
					str[i]=0x0b;
				}
				else if(str[i+1]!='\0' && str[i+1]!='\\')
				{	
						idxToDel = i;
						str[i]=str[i+1];
						memmove( &str[ idxToDel ] , &str[ idxToDel+1 ], strlen(str ) - idxToDel ) ;
				}
			}
		}
		int k=(int)strlen(str)-1;
		while(str[k]=='\\')
		{
			k--;
		}

		char * final=(char*)malloc(k*sizeof(char));//create memory for string which does not have backslashes at end
		for(i=0;i<=k;i++)
		{
			final[i]=str[i];
		}
		co=0;/*static variable for index of token string*/
		TokenizerT *ta=TKCreate(delim,final);/*object of struct*/
		while(co <(int)strlen(final)) /*this loop continues until index of token string is less than its length*/
		{
		
			int w=0;
			char *str=TKGetNextToken(ta);/*stores the token into str character pointer*/
			if(*str!='\0') /*if there is no token then this will print no token */   
			{
				for(w=0;w<(int)strlen(str);w++)/*it will loop through the returnes token*/
				{
					if(str[w]=='\n' || str[w]=='\t' || str[w]=='\f' ||str[w]=='\a'||str[w]=='\b'||str[w]=='\v' || str[w]=='\r' || str[w]=='\"' || str[w]=='\\')
					/*if there is special charachter in tokenized string then*/
					{ 
						printf("[0x%.2x]",str[w]);/*will print its hex number instead of special character*/
					}
				
					else
					{
						printf("%c",str[w]);
					}
				}
				printf("\n");
			}
			free(token);/*free the token*/
			token=NULL;
		}
		free(delim);//free my pointer for the delimiter string
		delim=NULL;
		free(str);//free my pointer for token string
		str=NULL;
		free(final);//free my pointer for final string which does not have end backslashes
		final=NULL;
		TKDestroy(ta);//call the destroy function to destroy the struct object
	}
	else
	{
		printf("ERROR: you must enter file name which needs to run and two other strings in order to continue: \n");
		return 1;
	}
	
	
	
       return 0;      
}
